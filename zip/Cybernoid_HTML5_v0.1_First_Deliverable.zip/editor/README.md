# Cybernoid Amiga — HTML5 Editor (v0.1)

This folder contains the new standalone browser editor. Open **`editor/index.html`** in a modern browser (or host the `editor/` directory as static files). No Python, Pygame, Node or web services are required to run it.

## Start

1. Click **Load GAME / GAED** and select the currently supported 383,230-byte Cybernoid `data/GAME` or `data/GAED` binary.
2. Choose a level (left), then an active logical room. The displayed physical room is looked up from the game where applicable.
3. Choose a tile on the right. To paint ordinary source tiles, enable **room tile painting**. Special controls and known compound-object cells are deliberately protected in v0.1.
4. Use pencil, line, rectangle, filled rectangle or bounded tile flood-fill. Right-click the room to pick a tile. Undo/Redo is available.
5. **Save Edits** produces `cybernoid-edits.json`, tied to the loaded source's CRC32 and original word values. Load the same base binary before **Import Edits**.
6. **Export GAED** validates core structural conditions and downloads a complete binary named `GAED`. Copy it to the Amiga installation as `data/GAED`; this is the file expected by the user's modified WHDLoad BOOT.

All imported data is processed locally. The editor does not write to Dropbox, GitHub or the source binary on your machine.

## Layout

- Top: Load GAME / GAED, Import Edits, Save Edits, Export GAED, Undo/Redo, Help.
- Left: levels, logical room map and read-only topology information, zoom and overlays.
- Centre: native 320×176 room canvas, zoomed with crisp indexed pixels; drawing tools below.
- Right: authentic 961-tile palette with behaviour filters, inspector and export validation.

The planned Tile Editor is a separate mode (16×16 pixel graphics + palette/brush tools). It is **not** implemented in this first release. Logical room topology is also **read-only** until more game transitions and active-slot rules have been verified.

## Implemented data model

- Reads **GAME bytes directly**, rather than requiring Python-extracted `project.json`.
- Recognises the documented relocated runtime-to-file offset, four level layouts, logical lookup, 961 4-plane tiles, Palette A/B and Level-4 eight-word override.
- Writes only edited 16-bit map cells onto a copy of the original data. No-edit export is byte-identical by construction.
- Protects known control words, anchors and their owned multi-tile footprints.
- Implements **core** checks for layout references, START/table mapping, landing pads, Level-4 portal records, known compounds, ELE endpoint pairs, generic-controller limits and anomalous >$3C0 words.

**Scope limitation:** This is *not* a full port of `tools/cybernoid_semantics.py` and the Python semantic-entity operation backend. Source variants with other sizes, descriptors or row strides are refused. The old Python code remains as a research/reference implementation, not as a runtime dependency.

Documentation: `docs/wiki/HTML5 Editor.md`, `docs/wiki/03-levels-rooms-and-topology.md`, `docs/wiki/04-graphics-palettes-and-frontend.md`, `docs/wiki/Further Investigations.md`.

## Browser testing status

The static page and the load → edit → Undo/Redo → export path have been exercised in headless Chromium with a **synthetic format-compatible binary**, including checking the exported file length (383,230 bytes). This is **not** a substitute for validating authentic images and game behaviour with the owner's GAME/GAED and WHDLoad installation.

The older `editor/cybernoid_editor.py` and `tools/*.py` remain untouched in the repository for reference and comparison. They do not need to be deleted to run the HTML5 editor.
